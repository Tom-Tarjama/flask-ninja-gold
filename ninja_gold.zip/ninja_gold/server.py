from flask import Flask, redirect, request, session, render_template
import random, datetime

ninja_gold = Flask(__name__)
ninja_gold.secret_key = "ThisIsSecret"

def timestamp():
	timestamp = datetime.datetime.now()
	timestamp = timestamp.strftime("%Y/%m/%d %I:%M %p")
	return timestamp


@ninja_gold.route('/')
def index(): # goes to main page

	if 'total_gold' not in session:
		session['total_gold'] = 0

	if 'activities' not in session:
		session['activities'] = []

	return render_template("index.html")

@ninja_gold.route('/process_money', methods=['POST'])
def process():

	if request.form['building'] == 'farm':
		session['new_gold'] = random.randrange(10,21)
		session['timestamp'] = timestamp()
		message = "You earned {} gold at the farm! ({})".format(session['new_gold'], session['timestamp'])
		session['activities'].append(message)
		session['total_gold'] += session['new_gold']

	elif request.form['building'] == 'cave':
		session['new_gold'] = random.randrange(5,11)
		session['timestamp'] = timestamp()
		message = "You earned {} gold at the cave! ({})".format(session['new_gold'], session['timestamp'])
		session['activities'].append(message)
		session['total_gold'] += session['new_gold']

	elif request.form['building'] == 'house':
		session['new_gold'] = random.randrange(2,6)
		session['timestamp'] = timestamp()
		message = "You earned {} gold at the house! ({})".format(session['new_gold'], session['timestamp'])
		session['activities'].append(message)
		session['total_gold'] += session['new_gold']

	elif request.form['building'] == 'casino':
		session['new_gold'] = random.randrange(-50,51)
		session['timestamp'] = timestamp()
		session['total_gold'] += session['new_gold']
		if session['new_gold'] < 0:
			session['new_gold'] = abs(session['new_gold'])
			message = "Oh noes! You lost {} gold at the casino! ({})".format(session['new_gold'], session['timestamp'])
		elif session['new_gold'] == 0:
			message = "Meh. You broke even at the casino. ({})".format(session['timestamp'])
		elif session['new_gold'] > 0:
			message = "Congrats! You won {} gold at the casino! ({})".format(session['new_gold'], session['timestamp'])
		session['activities'].append(message)

	return redirect('/')

@ninja_gold.route("/reset", methods=["POST"])
def reset():
	session['activities'] = []
	session['total_gold'] = 0

	return redirect('/')

ninja_gold.run(debug=True)